import React from "react";
import Main from "./src"

const App = () => {
  return (
    <Main />
  )
}

export default App